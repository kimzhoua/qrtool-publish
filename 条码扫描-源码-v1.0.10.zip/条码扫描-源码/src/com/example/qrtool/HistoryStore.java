package com.example.qrtool;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

/** 扫描历史：保存在本机（SharedPreferences 里的一段 JSON） */
public final class HistoryStore {

    private static final String PREF = "qrtool_history";
    private static final String KEY = "items";
    private static final int MAX = 300;

    private HistoryStore() {
    }

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public static JSONArray load(Context c) {
        String raw = sp(c).getString(KEY, "[]");
        try {
            return new JSONArray(raw);
        } catch (Throwable t) {
            return new JSONArray();
        }
    }

    /** 新增一条（最新的在最前；与最近一条完全相同则不重复记） */
    public static void add(Context c, String text, String format) {
        add(c, text, format, null);
    }

    /** 由格式判断分类：二维码 / 条形码 */
    public static String category(String format) {
        if (format == null) return "";
        switch (format) {
            case "QR_CODE":
            case "DATA_MATRIX":
            case "AZTEC":
            case "PDF_417":
                return "qr";
            case "EAN_13":
            case "EAN_8":
            case "UPC_A":
            case "UPC_E":
            case "CODE_128":
            case "CODE_39":
            case "CODE_93":
            case "ITF":
            case "CODABAR":
            case "RSS_14":
            case "RSS_EXPANDED":
                return "barcode";
            default:
                return "";
        }
    }

    public static void add(Context c, String text, String format, String imagePath) {
        if (text == null || text.length() == 0) return;
        JSONArray arr = load(c);
        JSONArray out = new JSONArray();
        try {
            if (arr.length() > 0) {
                JSONObject first = arr.getJSONObject(0);
                if (text.equals(first.optString("x")) && format.equals(first.optString("f"))) {
                    return;
                }
            }
            JSONObject item = new JSONObject();
            item.put("t", System.currentTimeMillis());
            item.put("f", format == null ? "" : format);
            item.put("c", category(format));
            item.put("x", text);
            if (imagePath != null && imagePath.length() > 0) item.put("i", imagePath);
            out.put(item);
            for (int i = 0; i < arr.length() && out.length() < MAX; i++) {
                JSONObject old = arr.getJSONObject(i);
                out.put(old);
                if (out.length() >= MAX) {
                    deleteImage(old.optString("i"));
                }
            }
        } catch (Throwable ignored) {
        }
        sp(c).edit().putString(KEY, out.toString()).apply();
    }

    public static void remove(Context c, long time, String text) {
        JSONArray arr = load(c);
        JSONArray out = new JSONArray();
        try {
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                if (o.optLong("t") == time && text.equals(o.optString("x"))) {
                    deleteImage(o.optString("i"));
                    continue;
                }
                out.put(o);
            }
        } catch (Throwable ignored) {
        }
        sp(c).edit().putString(KEY, out.toString()).apply();
    }

    public static void clear(Context c) {
        JSONArray arr = load(c);
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o != null) deleteImage(o.optString("i"));
        }
        sp(c).edit().putString(KEY, "[]").apply();
    }

    private static void deleteImage(String path) {
        try {
            if (path != null && path.length() > 0) new java.io.File(path).delete();
        } catch (Throwable ignored) {
        }
    }
}
