package com.example.qrtool;

import android.graphics.Bitmap;
import android.graphics.Color;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.NotFoundException;
import com.google.zxing.RGBLuminanceSource;
import com.google.zxing.Result;
import com.google.zxing.common.HybridBinarizer;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;

import java.util.HashMap;
import java.util.Map;

/** 二维码生成与图片解码 */
public final class QrUtils {

    private QrUtils() {
    }

    /** 生成二维码位图，白底黑码 */
    public static Bitmap encode(String text, int size) throws Exception {
        Map<EncodeHintType, Object> hints = new HashMap<>();
        hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");
        hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.M);
        hints.put(EncodeHintType.MARGIN, 1);
        com.google.zxing.common.BitMatrix matrix =
                new MultiFormatWriter().encode(text, BarcodeFormat.QR_CODE, size, size, hints);
        int[] pixels = new int[size * size];
        for (int y = 0; y < size; y++) {
            int offset = y * size;
            for (int x = 0; x < size; x++) {
                pixels[offset + x] = matrix.get(x, y) ? Color.BLACK : Color.WHITE;
            }
        }
        Bitmap bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        bmp.setPixels(pixels, 0, size, 0, 0, size, size);
        return bmp;
    }

    /** 从图片解码：返回 {内容, 格式}，失败返回 null */
    public static String[] decodeDetail(Bitmap bmp) {
        if (bmp == null) return null;
        Result r = decodeResult(bmp);
        if (r == null) return null;
        return new String[]{r.getText(), r.getBarcodeFormat() == null ? "" : r.getBarcodeFormat().name()};
    }

    private static Result decodeResult(Bitmap bmp) {
        int w = bmp.getWidth();
        int h = bmp.getHeight();
        if (w > 1000 || h > 1000) {
            float scale = 1000f / Math.max(w, h);
            bmp = Bitmap.createScaledBitmap(bmp, Math.max(1, (int) (w * scale)),
                    Math.max(1, (int) (h * scale)), true);
        }
        Result r = decodeResultOnce(bmp);
        if (r != null) return r;
        android.graphics.Matrix m = new android.graphics.Matrix();
        m.postRotate(90);
        Bitmap rotated = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(), m, false);
        return decodeResultOnce(rotated);
    }

    private static Result decodeResultOnce(Bitmap bmp) {
        int w = bmp.getWidth();
        int h = bmp.getHeight();
        int[] pixels = new int[w * h];
        bmp.getPixels(pixels, 0, w, 0, 0, w, h);
        try {
            RGBLuminanceSource source = new RGBLuminanceSource(w, h, pixels);
            BinaryBitmap bitmap = new BinaryBitmap(new HybridBinarizer(source));
            Map<com.google.zxing.DecodeHintType, Object> hints = new HashMap<>();
            hints.put(com.google.zxing.DecodeHintType.CHARACTER_SET, "UTF-8");
            hints.put(com.google.zxing.DecodeHintType.TRY_HARDER, Boolean.TRUE);
            return new MultiFormatReader().decode(bitmap, hints);
        } catch (Throwable t) {
            return null;
        }
    }

    /** 从图片里解码一个码，失败返回 null */
    public static String decode(Bitmap bmp) {
        if (bmp == null) return null;
        int w = bmp.getWidth();
        int h = bmp.getHeight();
        // 过大图片先缩到 1000px 以内，避免内存与耗时
        if (w > 1000 || h > 1000) {
            float scale = 1000f / Math.max(w, h);
            Bitmap small = Bitmap.createScaledBitmap(bmp,
                    Math.max(1, (int) (w * scale)), Math.max(1, (int) (h * scale)), true);
            String r = decodeOnce(small);
            if (r != null) return r;
            return decodeRotated(small);
        }
        String r = decodeOnce(bmp);
        if (r != null) return r;
        return decodeRotated(bmp);
    }

    private static String decodeRotated(Bitmap bmp) {
        android.graphics.Matrix m = new android.graphics.Matrix();
        m.postRotate(90);
        Bitmap rotated = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(), m, false);
        return decodeOnce(rotated);
    }

    /** 把相机 NV21 帧存成缩略图（旋转 90°、最长边 640），返回文件路径 */
    public static String saveFrame(byte[] nv21, int w, int h, File dir) {
        try {
            if (!dir.exists()) dir.mkdirs();
            android.graphics.YuvImage yuv =
                    new android.graphics.YuvImage(nv21, android.graphics.ImageFormat.NV21, w, h, null);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            yuv.compressToJpeg(new android.graphics.Rect(0, 0, w, h), 70, bos);
            byte[] jpg = bos.toByteArray();
            Bitmap raw = android.graphics.BitmapFactory.decodeByteArray(jpg, 0, jpg.length);
            if (raw == null) return null;
            android.graphics.Matrix m = new android.graphics.Matrix();
            m.postRotate(90);
            Bitmap rotated = Bitmap.createBitmap(raw, 0, 0, raw.getWidth(), raw.getHeight(), m, true);
            return saveBitmap(rotated, dir);
        } catch (Throwable t) {
            return null;
        }
    }

    /** 把图片存成缩略图（最长边 640），返回文件路径 */
    public static String saveBitmap(Bitmap bmp, File dir) {
        try {
            if (bmp == null) return null;
            if (!dir.exists()) dir.mkdirs();
            int w = bmp.getWidth();
            int h = bmp.getHeight();
            int max = Math.max(w, h);
            Bitmap out = bmp;
            if (max > 640) {
                float scale = 640f / max;
                out = Bitmap.createScaledBitmap(bmp, Math.max(1, (int) (w * scale)),
                        Math.max(1, (int) (h * scale)), true);
            }
            File f = new File(dir, "scan_" + System.currentTimeMillis() + ".jpg");
            FileOutputStream fos = new FileOutputStream(f);
            out.compress(Bitmap.CompressFormat.JPEG, 80, fos);
            fos.close();
            return f.getAbsolutePath();
        } catch (Throwable t) {
            return null;
        }
    }

    private static String decodeOnce(Bitmap bmp) {
        int w = bmp.getWidth();
        int h = bmp.getHeight();
        int[] pixels = new int[w * h];
        bmp.getPixels(pixels, 0, w, 0, 0, w, h);
        try {
            RGBLuminanceSource source = new RGBLuminanceSource(w, h, pixels);
            BinaryBitmap bitmap = new BinaryBitmap(new HybridBinarizer(source));
            Map<com.google.zxing.DecodeHintType, Object> hints = new HashMap<>();
            hints.put(com.google.zxing.DecodeHintType.CHARACTER_SET, "UTF-8");
            hints.put(com.google.zxing.DecodeHintType.TRY_HARDER, Boolean.TRUE);
            Result result = new MultiFormatReader().decode(bitmap, hints);
            return result.getText();
        } catch (NotFoundException e) {
            return null;
        } catch (Throwable t) {
            return null;
        }
    }
}
