package com.example.qrtool;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.hardware.Camera;
import android.os.Build;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.google.zxing.BinaryBitmap;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.PlanarYUVLuminanceSource;
import com.google.zxing.Result;
import com.google.zxing.common.HybridBinarizer;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** 相机扫码页：Camera1 预览 + 逐帧解码 */
public class ScanActivity extends Activity
        implements SurfaceHolder.Callback, Camera.PreviewCallback {

    private SurfaceView previewView;
    private Camera camera;
    private TextView hintView;
    private volatile boolean decoding = false;
    private volatile boolean finished = false;
    private volatile String lastFormat = "";
    private volatile boolean hasFrame = false;
    private String mode = "qr";

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                getResources().getDisplayMetrics());
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            setupUi();
        } catch (Throwable t) {
            android.widget.Toast.makeText(this, "扫码页初始化失败：" + t, android.widget.Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private void setupUi() {
        FrameLayout container = new FrameLayout(this);
        container.setBackgroundColor(Color.BLACK);

        previewView = new SurfaceView(this);
        container.addView(previewView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        previewView.getHolder().addCallback(this);

        hintView = new TextView(this);
        mode = getIntent().getStringExtra("mode");
        if (mode == null || mode.length() == 0) mode = "both";
        if ("barcode".equals(mode)) {
            hintView.setText("把条形码横放进取景框，自动识别");
        } else if ("qr".equals(mode)) {
            hintView.setText("把二维码放进取景框，自动识别");
        } else {
            hintView.setText("二维码或条形码放进取景框即可");
        }
        hintView.setTextColor(Color.WHITE);
        hintView.setTextSize(14);
        hintView.setGravity(Gravity.CENTER);
        hintView.setBackgroundColor(0x66000000);
        hintView.setPadding(dp(16), dp(10), dp(16), dp(10));
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        hp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        hp.topMargin = dp(28);
        container.addView(hintView, hp);

        TextView close = new TextView(this);
        close.setText("关闭");
        close.setTextColor(Color.WHITE);
        close.setTextSize(15);
        close.setGravity(Gravity.CENTER);
        close.setBackgroundColor(0x66000000);
        close.setPadding(dp(18), dp(10), dp(18), dp(10));
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        cp.bottomMargin = dp(32);
        close.setLayoutParams(cp);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        container.addView(close);

        setContentView(container);

        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, 10);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 10) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                holderRef = previewView.getHolder();
                openCamera();
            } else {
                hintView.setText("没有相机权限，无法扫码。请到系统设置里允许相机权限");
            }
        }
    }

    private SurfaceHolder holderRef;

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        holderRef = holder;
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            openCamera();
        }
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        holderRef = holder;
        // 某些机型切回前台时 surface 尺寸变化，需要重新绑定并恢复预览
        if (camera != null) {
            try {
                camera.stopPreview();
            } catch (Throwable ignored) {
            }
            try {
                camera.setPreviewDisplay(holder);
                camera.setPreviewCallback(this);
                camera.startPreview();
            } catch (Throwable t) {
                releaseCamera();
                showCameraProblem();
            }
        }
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        releaseCamera();
    }

    /** 保持相机画面比例：等比放大到铺满屏幕并居中裁切，避免上下拉伸 */
    private void applyPreviewLayout() {
        if (previewWidth <= 0 || previewHeight <= 0 || previewView == null) return;
        int screenW = getResources().getDisplayMetrics().widthPixels;
        int screenH = getResources().getDisplayMetrics().heightPixels;
        // 预览已旋转 90°，所以屏幕上的宽对应 previewHeight，高对应 previewWidth
        double dispW = previewHeight;
        double dispH = previewWidth;
        double scale = Math.max(screenW / dispW, screenH / dispH);
        int vw = (int) (dispW * scale);
        int vh = (int) (dispH * scale);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(vw, vh);
        lp.gravity = Gravity.CENTER;
        previewView.setLayoutParams(lp);
    }

    private boolean surfaceReady() {
        return holderRef != null && holderRef.getSurface() != null
                && holderRef.getSurface().isValid();
    }

    private void openCamera() {
        if (camera != null) return;
        if (!surfaceReady()) {
            // Surface 还没准备好，等 surfaceCreated 回调再来
            return;
        }
        try {
            camera = Camera.open();
        } catch (Throwable t) {
            camera = null;
        }
        if (camera == null) {
            showCameraProblem();
            return;
        }
        try {
            Camera.Parameters p = camera.getParameters();
            // 取一个中等分辨率预览，解码够用且不卡
            List<Camera.Size> sizes = p.getSupportedPreviewSizes();
            Camera.Size best = null;
            for (Camera.Size s : sizes) {
                if (s.width >= 960 && s.width <= 1600) {
                    if (best == null || Math.abs(s.width - 1280) < Math.abs(best.width - 1280)) best = s;
                }
            }
            if (best == null && sizes.size() > 0) best = sizes.get(sizes.size() / 2);
            if (best != null) {
                p.setPreviewSize(best.width, best.height);
                previewWidth = best.width;
                previewHeight = best.height;
            }

            List<String> focusModes = p.getSupportedFocusModes();
            if (focusModes != null) {
                if (focusModes.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE)) {
                    p.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE);
                } else if (focusModes.contains(Camera.Parameters.FOCUS_MODE_AUTO)) {
                    p.setFocusMode(Camera.Parameters.FOCUS_MODE_AUTO);
                }
            }
            camera.setParameters(p);
            camera.setDisplayOrientation(90);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    applyPreviewLayout();
                }
            });
            camera.setPreviewDisplay(holderRef);
            camera.setPreviewCallback(this);
            camera.startPreview();
            if (!hasFrame) {
                // 某些机型首帧不来，重设一次回调促发
                camera.setPreviewCallback(this);
            }
        } catch (Throwable t) {
            releaseCamera();
            showCameraProblem();
        }
    }

    /** 相机不可用时，允许改用系统相机拍一张再识别 */
    private void showCameraProblem() {
        if (isFinishing()) return;
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                new android.app.AlertDialog.Builder(ScanActivity.this)
                        .setTitle("无法启动相机预览")
                        .setMessage("这台设备没能打开实时取景（可能是相机权限未授予、相机被其他应用占用，或系统限制）。\n可以改用「拍照识别」：调用系统相机拍一张，再自动识别其中的码。")
                        .setPositiveButton("拍照识别", new android.content.DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(android.content.DialogInterface d, int w) {
                                takePhotoFallback();
                            }
                        })
                        .setNegativeButton("关闭", new android.content.DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(android.content.DialogInterface d, int w) {
                                finish();
                            }
                        })
                        .show();
            }
        });
    }

    private android.net.Uri pendingPhotoUri;

    private void takePhotoFallback() {
        try {
            android.content.ContentValues values = new android.content.ContentValues();
            values.put(android.provider.MediaStore.Images.Media.DISPLAY_NAME,
                    "scan_" + System.currentTimeMillis() + ".jpg");
            values.put(android.provider.MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            if (Build.VERSION.SDK_INT >= 29) {
                values.put(android.provider.MediaStore.Images.Media.RELATIVE_PATH, "Pictures/条码扫描");
            }
            pendingPhotoUri = getContentResolver().insert(
                    android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (pendingPhotoUri == null) {
                hintView.setText("无法创建照片文件");
                return;
            }
            android.content.Intent intent = new android.content.Intent(
                    android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
            intent.putExtra(android.provider.MediaStore.EXTRA_OUTPUT, pendingPhotoUri);
            startActivityForResult(intent, 200);
        } catch (Throwable t) {
            hintView.setText("调用系统相机失败：" + t.getMessage());
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, android.content.Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != 200) return;
        if (resultCode != RESULT_OK || pendingPhotoUri == null) {
            finish();
            return;
        }
        try {
            android.graphics.Bitmap bmp = android.provider.MediaStore.Images.Media
                    .getBitmap(getContentResolver(), pendingPhotoUri);
            String text = QrUtils.decode(bmp);
            if (text == null) {
                android.widget.Toast.makeText(this, "照片里没识别到码", android.widget.Toast.LENGTH_LONG).show();
                finish();
                return;
            }
            android.content.Intent out = new android.content.Intent();
            out.putExtra("text", text);
            out.putExtra("mode", mode);
            out.putExtra("format", "");
            setResult(RESULT_OK, out);
            finish();
        } catch (Throwable t) {
            android.widget.Toast.makeText(this, "读取照片失败：" + t.getMessage(), android.widget.Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private void releaseCamera() {
        if (camera != null) {
            try {
                camera.setPreviewCallback(null);
                camera.stopPreview();
            } catch (Throwable ignored) {
            }
            try {
                camera.release();
            } catch (Throwable ignored) {
            }
            camera = null;
        }
    }

    private int previewWidth = 0;
    private int previewHeight = 0;

    @Override
    public void onPreviewFrame(byte[] data, Camera cam) {
        if (decoding || finished || data == null) return;
        hasFrame = true;
        if (previewWidth <= 0 || previewHeight <= 0) {
            Camera.Parameters p = cam.getParameters();
            if (p == null || p.getPreviewSize() == null) return;
            previewWidth = p.getPreviewSize().width;
            previewHeight = p.getPreviewSize().height;
        }
        final int w = previewWidth;
        final int h = previewHeight;
        final byte[] frame = data.clone();
        decoding = true;
        new Thread(new Runnable() {
            @Override
            public void run() {
                java.util.List<Result> found = null;
                try {
                    PlanarYUVLuminanceSource source =
                            new PlanarYUVLuminanceSource(frame, w, h, 0, 0, w, h, false);
                    found = scanSource(source);
                    if (found.isEmpty()) found = scanSource(source.rotateCounterClockwise());
                    if (found.isEmpty()) {
                        found = scanSource(source.rotateCounterClockwise().rotateCounterClockwise());
                    }
                } catch (Throwable ignored) {
                }
                decoding = false;
                if (found == null || found.isEmpty() || finished) return;

                if (found.size() == 1) {
                    final Result only = found.get(0);
                    finished = true;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            returnResult(only.getText(),
                                    only.getBarcodeFormat() == null ? "" : only.getBarcodeFormat().name());
                        }
                    });
                } else {
                    finished = true;
                    final java.util.List<Result> list = found;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            chooseResult(list);
                        }
                    });
                }
            }
        }).start();
    }

    private void returnResult(String text, String format) {
        Intent out = new Intent();
        out.putExtra("text", text);
        out.putExtra("format", format);
        out.putExtra("mode", mode);
        setResult(RESULT_OK, out);
        finish();
    }

    /** 画面里有多个码时让用户选一个 */
    private void chooseResult(final java.util.List<Result> list) {
        String[] labels = new String[list.size()];
        for (int i = 0; i < list.size(); i++) {
            String t = list.get(i).getText();
            String f = list.get(i).getBarcodeFormat() == null ? "" : list.get(i).getBarcodeFormat().name();
            if (t.length() > 40) t = t.substring(0, 40) + "…";
            labels[i] = (i + 1) + ".  " + t + (f.length() > 0 ? "\n" + f : "");
        }
        new android.app.AlertDialog.Builder(this)
                .setTitle("画面里有 " + list.size() + " 个码，选一个")
                .setItems(labels, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int which) {
                        Result r = list.get(which);
                        returnResult(r.getText(),
                                r.getBarcodeFormat() == null ? "" : r.getBarcodeFormat().name());
                    }
                })
                .setNegativeButton("重新扫", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        finished = false;
                    }
                })
                .show();
    }

    /** 一帧里可能包含多个码，返回全部结果（去重） */
    private java.util.List<Result> scanSource(com.google.zxing.LuminanceSource source) {
        java.util.List<Result> out = new java.util.ArrayList<>();
        BinaryBitmap bb = new BinaryBitmap(new HybridBinarizer(source));
        boolean wantBarcode = "barcode".equals(mode) || "both".equals(mode);
        boolean wantQr = "qr".equals(mode) || "both".equals(mode);

        Map<com.google.zxing.DecodeHintType, Object> hints = new HashMap<>();
        hints.put(com.google.zxing.DecodeHintType.CHARACTER_SET, "UTF-8");
        hints.put(com.google.zxing.DecodeHintType.TRY_HARDER, Boolean.TRUE);
        java.util.List<com.google.zxing.BarcodeFormat> formats = new java.util.ArrayList<>();
        if (wantBarcode) {
            formats.add(com.google.zxing.BarcodeFormat.EAN_13);
            formats.add(com.google.zxing.BarcodeFormat.EAN_8);
            formats.add(com.google.zxing.BarcodeFormat.UPC_A);
            formats.add(com.google.zxing.BarcodeFormat.UPC_E);
            formats.add(com.google.zxing.BarcodeFormat.CODE_128);
            formats.add(com.google.zxing.BarcodeFormat.CODE_39);
            formats.add(com.google.zxing.BarcodeFormat.CODE_93);
            formats.add(com.google.zxing.BarcodeFormat.ITF);
            formats.add(com.google.zxing.BarcodeFormat.CODABAR);
        }
        if (wantQr) {
            formats.add(com.google.zxing.BarcodeFormat.QR_CODE);
            formats.add(com.google.zxing.BarcodeFormat.DATA_MATRIX);
            formats.add(com.google.zxing.BarcodeFormat.AZTEC);
        }
        hints.put(com.google.zxing.DecodeHintType.POSSIBLE_FORMATS, formats);

        if (wantQr) {
            try {
                Result[] rs = new com.google.zxing.multi.qrcode.QRCodeMultiReader()
                        .decodeMultiple(bb, hints);
                if (rs != null) java.util.Collections.addAll(out, rs);
            } catch (Throwable ignored) {
            }
        }
        if (wantBarcode && out.isEmpty()) {
            try {
                Result[] rs = new com.google.zxing.multi.GenericMultipleBarcodeReader(
                        new com.google.zxing.oned.MultiFormatOneDReader(hints))
                        .decodeMultiple(bb, hints);
                if (rs != null) java.util.Collections.addAll(out, rs);
            } catch (Throwable ignored) {
            }
        }
        if (out.isEmpty()) {
            try {
                Result r = new MultiFormatReader().decode(bb, hints);
                if (r != null) out.add(r);
            } catch (Throwable ignored) {
            }
        }
        // 去重（同一内容只留一条）
        java.util.List<Result> uniq = new java.util.ArrayList<>();
        java.util.Set<String> seen = new java.util.HashSet<>();
        for (Result r : out) {
            if (r == null || r.getText() == null) continue;
            if (seen.add(r.getText())) uniq.add(r);
        }
        return uniq;
    }

    private String decodeSource(com.google.zxing.LuminanceSource source) {
        java.util.List<Result> list = scanSource(source);
        return list.isEmpty() ? null : list.get(0).getText();
    }

    @Override
    protected void onPause() {
        super.onPause();
        releaseCamera();
    }

    @Override
    protected void onResume() {
        super.onResume();
        finished = false;
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                && surfaceReady() && camera == null) {
            openCamera();
        }
    }

    @Override
    protected void onDestroy() {
        releaseCamera();
        super.onDestroy();
    }
}
