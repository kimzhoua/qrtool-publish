package com.example.qrtool;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** 扫描历史：搜索、复制、单条删除、清空 */
public class HistoryActivity extends Activity {

    private LinearLayout listBox;
    private TextView emptyView;
    private String keyword = "";
    private final SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        immersive();
        build();
    }

    private void immersive() {
        Window w = getWindow();
        w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        w.setStatusBarColor(0x00000000);
        if (Build.VERSION.SDK_INT >= 26) w.setNavigationBarColor(0x00000000);
        int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        if (Build.VERSION.SDK_INT >= 26) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        w.getDecorView().setSystemUiVisibility(flags);
    }

    private int statusBarHeight() {
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : dp(24);
    }

    private void build() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFFE6F0FF, 0xFFF2F7FF, 0xFFEDF4FF, 0xFFF9FBFF}));
        scroll.setFillViewport(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), statusBarHeight() + dp(14), dp(18), dp(24));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);

        TextView back = new TextView(this);
        back.setText("‹ 返回");
        back.setTextSize(14);
        back.setTextColor(0xFF2F6BFF);
        back.setPadding(0, dp(6), dp(10), dp(6));
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        bar.addView(back);

        TextView title = new TextView(this);
        title.setText("扫描历史");
        title.setTextSize(20);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        title.setTextColor(0xFF16233A);
        title.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        bar.addView(title);

        TextView clear = new TextView(this);
        clear.setText("清空");
        clear.setTextSize(13);
        clear.setTextColor(0xFF2F6BFF);
        clear.setPadding(dp(10), dp(6), 0, dp(6));
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(HistoryActivity.this)
                        .setTitle("清空扫描历史")
                        .setMessage("删除全部记录？不可恢复。")
                        .setPositiveButton("清空", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int w) {
                                HistoryStore.clear(HistoryActivity.this);
                                refresh();
                            }
                        })
                        .setNegativeButton("取消", null)
                        .show();
            }
        });
        bar.addView(clear);
        root.addView(bar);

        EditText search = new EditText(this);
        search.setHint("搜索内容或码类型");
        search.setTextSize(14);
        search.setSingleLine(true);
        search.setInputType(InputType.TYPE_CLASS_TEXT);
        search.setTextColor(0xFF1B2230);
        search.setPadding(dp(12), dp(8), dp(12), dp(8));
        GradientDrawable sbg = rounded(0xFFFFFFFF, 12);
        sbg.setStroke(dp(1), 0x33A9C4EA);
        search.setBackground(sbg);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        slp.topMargin = dp(10);
        search.setLayoutParams(slp);
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                keyword = s.toString().trim().toLowerCase(Locale.getDefault());
                refresh();
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
        root.addView(search);

        listBox = new LinearLayout(this);
        listBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(listBox);

        emptyView = new TextView(this);
        emptyView.setText("还没有扫描记录");
        emptyView.setTextSize(13);
        emptyView.setTextColor(0xFF98A0AE);
        emptyView.setGravity(Gravity.CENTER);
        emptyView.setPadding(0, dp(40), 0, 0);
        root.addView(emptyView);

        scroll.addView(root);
        setContentView(scroll);
        refresh();
    }

    private void refresh() {
        listBox.removeAllViews();
        JSONArray arr = HistoryStore.load(this);
        int shown = 0;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            final String text = o.optString("x");
            final String format = o.optString("f");
            final long time = o.optLong("t");
            String hay = (text + " " + format).toLowerCase(Locale.getDefault());
            if (keyword.length() > 0 && !hay.contains(keyword)) continue;
            listBox.addView(row(text, format, time));
            shown++;
        }
        emptyView.setVisibility(shown == 0 ? View.VISIBLE : View.GONE);
        emptyView.setText(keyword.length() > 0 ? "没有匹配的记录" : "还没有扫描记录");
    }

    private View row(final String text, final String format, final long time) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(10), dp(14), dp(10));
        GradientDrawable bg = rounded(0xF2FFFFFF, 16);
        bg.setStroke(dp(1), 0x55FFFFFF);
        box.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(8);
        box.setLayoutParams(lp);

        TextView content = new TextView(this);
        content.setText(text);
        content.setTextSize(14);
        content.setMaxLines(3);
        content.setTextColor(0xFF1B2230);
        box.addView(content);

        TextView meta = new TextView(this);
        meta.setText(fmt.format(new Date(time)) + (format.length() > 0 ? "  ·  " + format : ""));
        meta.setTextSize(11);
        meta.setTextColor(0xFF98A0AE);
        meta.setPadding(0, dp(4), 0, 0);
        box.addView(meta);

        box.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("扫描内容", text));
                Toast.makeText(HistoryActivity.this, "已复制", Toast.LENGTH_SHORT).show();
            }
        });
        box.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                new AlertDialog.Builder(HistoryActivity.this)
                        .setTitle("删除这条记录？")
                        .setPositiveButton("删除", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int w) {
                                HistoryStore.remove(HistoryActivity.this, time, text);
                                refresh();
                            }
                        })
                        .setNegativeButton("取消", null)
                        .show();
                return true;
            }
        });
        return box;
    }
}
