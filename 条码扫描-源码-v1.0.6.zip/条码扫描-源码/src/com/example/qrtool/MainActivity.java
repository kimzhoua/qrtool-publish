package com.example.qrtool;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.OutputStream;

/** 二维码工具箱主界面：生成 / 扫码 / 图片识别 */
public class MainActivity extends Activity {

    static final String PREF = "qrtool";
    private static final int REQ_SCAN = 100;
    private static final int REQ_PICK = 101;
    private static final int REQ_BATCH = 102;
    private static final int REQ_HISTORY = 103;

    private EditText input;
    private ImageView qrView;
    private LinearLayout qrCard;
    private LinearLayout actionRow;
    private Bitmap currentQr;
    private String currentText = "";
    private OtaManager otaManager;
    private android.app.Dialog settingsDialog;

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private android.graphics.drawable.Drawable pageBackground() {
        return new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFFE6F0FF, 0xFFF2F7FF, 0xFFEDF4FF, 0xFFF9FBFF});
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            otaManager = new OtaManager(this);
            applyImmersiveStatusBar();
            buildUi();
        } catch (Throwable t) {
            showCrash("启动", t);
        }
    }

    /** 崩溃兜底：把异常直接显示出来，方便定位，而不是直接闪退 */
    private void showCrash(String where, Throwable t) {
        try {
            java.io.StringWriter sw = new java.io.StringWriter();
            t.printStackTrace(new java.io.PrintWriter(sw));
            final String trace = where + "\n" + sw.toString();
            android.app.AlertDialog.Builder b = new android.app.AlertDialog.Builder(this);
            b.setTitle("程序出错（" + where + "）");
            b.setMessage(trace.length() > 1500 ? trace.substring(0, 1500) : trace);
            b.setPositiveButton("复制错误信息", new android.content.DialogInterface.OnClickListener() {
                @Override
                public void onClick(android.content.DialogInterface d, int which) {
                    copy(trace);
                }
            });
            b.setNegativeButton("关闭", null);
            b.show();
        } catch (Throwable ignored) {
        }
    }

    /** 沉浸式状态栏：状态栏透明、图标深色，内容延伸到状态栏下方 */
    private void applyImmersiveStatusBar() {
        Window w = getWindow();
        w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        w.setStatusBarColor(0x00000000);
        if (Build.VERSION.SDK_INT >= 26) w.setNavigationBarColor(0x00000000);
        int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        if (Build.VERSION.SDK_INT >= 26) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        w.getDecorView().setSystemUiVisibility(flags);
    }

    private int statusBarHeight() {
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : dp(24);
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackground(pageBackground());
        scroll.setFillViewport(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(pageBackground());
        root.setPadding(dp(18), statusBarHeight() + dp(14), dp(18), dp(26));

        // 标题行 + 齿轮
        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(this);
        title.setText("条码扫描");
        title.setTextSize(22);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        title.setTextColor(0xFF16233A);
        title.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        titleRow.addView(title);

        ImageView gear = new ImageView(this);
        gear.setImageResource(R.drawable.ic_settings_gear);
        gear.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        int gs = dp(38);
        gear.setLayoutParams(new LinearLayout.LayoutParams(gs, gs));
        GradientDrawable gearBg = rounded(0xFFFFFFFF, 12);
        gearBg.setStroke(dp(1), 0x33A9C4EA);
        gear.setBackground(gearBg);
        gear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSettings();
            }
        });
        titleRow.addView(gear);
        root.addView(titleRow);

        TextView sub = new TextView(this);
        sub.setText("二维码生成 · 相机扫码 · 条码识别");
        sub.setTextSize(12);
        sub.setTextColor(0xFF7A8699);
        sub.setPadding(0, dp(5), 0, dp(12));
        root.addView(sub);

        // 输入卡
        LinearLayout inputCard = card();
        TextView label = new TextView(this);
        label.setText("文本 / 网址");
        label.setTextSize(13);
        label.setTextColor(0xFF6B7482);
        inputCard.addView(label);

        input = new EditText(this);
        input.setText("https://github.com/kimzhoua");
        input.setTextSize(15);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        input.setMinLines(2);
        input.setTextColor(0xFF1B2230);
        input.setHint("输入要生成二维码的内容");
        input.setPadding(dp(12), dp(8), dp(12), dp(8));
        GradientDrawable inBg = rounded(0xE8FFFFFF, 12);
        inBg.setStroke(dp(1), 0x33A9C4EA);
        input.setBackground(inBg);
        LinearLayout.LayoutParams inLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        inLp.topMargin = dp(6);
        input.setLayoutParams(inLp);
        inputCard.addView(input);

        TextView genBtn = new TextView(this);
        genBtn.setText("生成二维码");
        genBtn.setTextSize(15);
        genBtn.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        genBtn.setTextColor(0xFFFFFFFF);
        genBtn.setGravity(Gravity.CENTER);
        GradientDrawable genBg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{0xFF2F6BFF, 0xFF4F8DFF});
        genBg.setCornerRadius(dp(14));
        genBtn.setBackground(genBg);
        LinearLayout.LayoutParams gbLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(46));
        gbLp.topMargin = dp(10);
        genBtn.setLayoutParams(gbLp);
        genBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                generate();
            }
        });
        inputCard.addView(genBtn);
        root.addView(inputCard);

        // 二维码展示卡（未生成时隐藏）
        qrCard = card();
        qrCard.setVisibility(View.GONE);

        qrView = new ImageView(this);
        qrView.setAdjustViewBounds(true);
        qrView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams qlp = new LinearLayout.LayoutParams(dp(220), dp(220));
        qlp.gravity = Gravity.CENTER_HORIZONTAL;
        qlp.topMargin = dp(4);
        qrView.setLayoutParams(qlp);
        qrCard.addView(qrView);

        actionRow = new LinearLayout(this);
        actionRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams arLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        arLp.topMargin = dp(8);
        actionRow.setLayoutParams(arLp);

        actionRow.addView(smallButton("保存到相册", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveToGallery();
            }
        }));
        actionRow.addView(smallButton("分享", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shareQr();
            }
        }));
        actionRow.addView(smallButton("复制内容", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                copy(currentText);
                Toast.makeText(MainActivity.this, "已复制", Toast.LENGTH_SHORT).show();
            }
        }));
        qrCard.addView(actionRow);

        root.addView(qrCard);

        // 识别卡
        LinearLayout scanCard = card();
        TextView scanLabel = new TextView(this);
        scanLabel.setText("识别");
        scanLabel.setTextSize(13);
        scanLabel.setTextColor(0xFF6B7482);
        scanCard.addView(scanLabel);

        LinearLayout scanRow = new LinearLayout(this);
        scanRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams srLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        srLp.topMargin = dp(8);
        scanRow.setLayoutParams(srLp);
        scanRow.addView(modeButton("扫二维码", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openScan("qr");
            }
        }));
        scanRow.addView(modeButton("扫条形码", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openScan("barcode");
            }
        }));
        scanRow.addView(modeButton("两个都扫", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openScan("both");
            }
        }));
        scanCard.addView(scanRow);

        TextView pickBtn = new TextView(this);
        pickBtn.setText("从图片识别二维码或条码");
        pickBtn.setTextSize(14);
        pickBtn.setTextColor(0xFF2F6BFF);
        pickBtn.setGravity(Gravity.CENTER);
        GradientDrawable pbg = rounded(0xFFFFFFFF, 14);
        pbg.setStroke(dp(1), 0x552F6BFF);
        pickBtn.setBackground(pbg);
        LinearLayout.LayoutParams pbLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(44));
        pbLp.topMargin = dp(8);
        pickBtn.setLayoutParams(pbLp);
        pickBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickImage();
            }
        });
        scanCard.addView(pickBtn);

        LinearLayout moreRow = new LinearLayout(this);
        moreRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams mrLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        mrLp.topMargin = dp(8);
        moreRow.setLayoutParams(mrLp);
        moreRow.addView(smallButton("批量识别图片", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickBatch();
            }
        }));
        moreRow.addView(smallButton("扫描历史", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityForResult(new Intent(MainActivity.this, HistoryActivity.class), REQ_HISTORY);
            }
        }));
        scanCard.addView(moreRow);

        root.addView(scanCard);

        TextView tip = new TextView(this);
        tip.setText("全部在本地完成，不上传任何内容。");
        tip.setTextSize(11);
        tip.setTextColor(0xFF98A0AE);
        tip.setPadding(dp(2), dp(10), dp(2), 0);
        root.addView(tip);

        scroll.addView(root);
        setContentView(scroll);
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable bg = rounded(0xF2FFFFFF, 20);
        bg.setStroke(dp(1), 0x66FFFFFF);
        c.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(10);
        c.setLayoutParams(lp);
        return c;
    }

    private View smallButton(String text, View.OnClickListener l) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(13);
        tv.setTextColor(0xFF2F6BFF);
        tv.setGravity(Gravity.CENTER);
        GradientDrawable bg = rounded(0xFFEFF4FF, 12);
        tv.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                0, dp(40), 1f);
        lp.rightMargin = dp(4);
        lp.leftMargin = dp(4);
        tv.setLayoutParams(lp);
        tv.setOnClickListener(l);
        return tv;
    }

    private View primaryButton(String text, View.OnClickListener l) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(15);
        tv.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        tv.setTextColor(0xFFFFFFFF);
        tv.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{0xFF2F6BFF, 0xFF4F8DFF});
        bg.setCornerRadius(dp(14));
        tv.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(46), 1f);
        lp.rightMargin = dp(5);
        tv.setLayoutParams(lp);
        tv.setOnClickListener(l);
        return tv;
    }

    /** 三个等分模式按钮之一（白底蓝字） */
    private View modeButton(String text, View.OnClickListener l) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(14);
        tv.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        tv.setTextColor(0xFF2F6BFF);
        tv.setGravity(Gravity.CENTER);
        GradientDrawable bg = rounded(0xFFFFFFFF, 14);
        bg.setStroke(dp(1), 0x552F6BFF);
        tv.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(46), 1f);
        lp.rightMargin = dp(4);
        lp.leftMargin = dp(4);
        tv.setLayoutParams(lp);
        tv.setOnClickListener(l);
        return tv;
    }

    private View secondaryButton(String text, View.OnClickListener l) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(15);
        tv.setTextColor(0xFF2F6BFF);
        tv.setGravity(Gravity.CENTER);
        GradientDrawable bg = rounded(0xFFFFFFFF, 14);
        bg.setStroke(dp(1), 0x552F6BFF);
        tv.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(46), 1f);
        lp.leftMargin = dp(5);
        tv.setLayoutParams(lp);
        tv.setOnClickListener(l);
        return tv;
    }

    private void generate() {
        String text = input.getText().toString().trim();
        if (text.length() == 0) {
            Toast.makeText(this, "请先输入内容", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            int size = dp(220);
            if (size <= 0) size = 220;
            currentQr = QrUtils.encode(text, size);
            currentText = text;
            qrView.setImageBitmap(currentQr);
            qrCard.setVisibility(View.VISIBLE);
        } catch (Throwable t) {
            Toast.makeText(this, "生成失败：" + t.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    /** 写入相册，返回可分享的 Uri；失败返回 null */
    private Uri saveToGalleryQuiet() {
        if (currentQr == null) return null;
        try {
            long now = System.currentTimeMillis();
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, "qr_" + now + ".png");
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            if (Build.VERSION.SDK_INT >= 29) {
                values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/二维码工具箱");
                values.put(MediaStore.Images.Media.IS_PENDING, 1);
            }
            Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) return null;
            OutputStream os = getContentResolver().openOutputStream(uri);
            currentQr.compress(Bitmap.CompressFormat.PNG, 100, os);
            os.close();
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues done = new ContentValues();
                done.put(MediaStore.Images.Media.IS_PENDING, 0);
                getContentResolver().update(uri, done, null, null);
            }
            return uri;
        } catch (Throwable t) {
            return null;
        }
    }

    private void saveToGallery() {
        Uri uri = saveToGalleryQuiet();
        if (uri == null) {
            Toast.makeText(this, "保存失败，请检查相册权限", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "已保存到相册", Toast.LENGTH_SHORT).show();
        }
    }

    private void shareQr() {
        if (currentQr == null) return;
        Uri uri = saveToGalleryQuiet();
        if (uri == null) {
            Toast.makeText(this, "分享失败，请检查相册权限", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("image/png");
            share.putExtra(Intent.EXTRA_STREAM, uri);
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(share, "分享二维码"));
        } catch (Throwable t) {
            Toast.makeText(this, "分享失败：" + t.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void openScan(String mode) {
        Intent intent = new Intent(this, ScanActivity.class);
        intent.putExtra("mode", mode);
        startActivityForResult(intent, REQ_SCAN);
    }

    private void pickBatch() {
        Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
        pick.setType("image/*");
        pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        try {
            startActivityForResult(Intent.createChooser(pick, "选择多张图片"), REQ_BATCH);
        } catch (Throwable t) {
            Toast.makeText(this, "没有可用的相册应用", Toast.LENGTH_SHORT).show();
        }
    }

    private void handleBatch(Intent data) {
        java.util.ArrayList<Uri> uris = new java.util.ArrayList<>();
        ClipData clip = data.getClipData();
        if (clip != null) {
            for (int i = 0; i < clip.getItemCount(); i++) {
                if (clip.getItemAt(i).getUri() != null) uris.add(clip.getItemAt(i).getUri());
            }
        } else if (data.getData() != null) {
            uris.add(data.getData());
        }
        if (uris.isEmpty()) return;

        final android.app.ProgressDialog pd = new android.app.ProgressDialog(this);
        pd.setMessage("正在识别 0/" + uris.size());
        pd.setCancelable(false);
        pd.show();

        final java.util.ArrayList<Uri> list = uris;
        final StringBuilder sb = new StringBuilder();
        final int[] okCount = {0};
        new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < list.size(); i++) {
                    final int idx = i;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            pd.setMessage("正在识别 " + (idx + 1) + "/" + list.size());
                        }
                    });
                    String text = null;
                    try {
                        Bitmap bmp = MediaStore.Images.Media.getBitmap(getContentResolver(), list.get(i));
                        text = QrUtils.decode(bmp);
                    } catch (Throwable ignored) {
                    }
                    if (text != null) {
                        okCount[0]++;
                        sb.append(okCount[0]).append(". ").append(text).append("\n\n");
                        HistoryStore.add(MainActivity.this, text, "");
                    }
                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        pd.dismiss();
                        if (okCount[0] == 0) {
                            Toast.makeText(MainActivity.this,
                                    "这 " + list.size() + " 张图里都没识别到码", Toast.LENGTH_LONG).show();
                        } else {
                            showBatchResult(okCount[0], list.size(), sb.toString().trim());
                        }
                    }
                });
            }
        }).start();
    }

    private void showBatchResult(int ok, int total, final String content) {
        android.app.Dialog dialog = new android.app.Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(16), dp(18), dp(14));
        card.setBackground(rounded(0xFFFFFFFF, 20));

        TextView t = new TextView(this);
        t.setText("批量识别完成 · " + ok + "/" + total);
        t.setTextSize(15);
        t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        t.setTextColor(0xFF16233A);
        card.addView(t);

        android.widget.ScrollView sc = new android.widget.ScrollView(this);
        TextView tv = new TextView(this);
        tv.setText(content);
        tv.setTextSize(13);
        tv.setTextIsSelectable(true);
        tv.setTextColor(0xFF1B2230);
        tv.setPadding(dp(12), dp(10), dp(12), dp(10));
        tv.setBackground(rounded(0xFFF6F7FB, 12));
        sc.addView(tv);
        LinearLayout.LayoutParams scLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(260));
        scLp.topMargin = dp(8);
        sc.setLayoutParams(scLp);
        card.addView(sc);

        final android.app.Dialog dlg = dialog;
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rlp.topMargin = dp(10);
        row.setLayoutParams(rlp);
        row.addView(smallButton("复制全部", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                copy(content);
                Toast.makeText(MainActivity.this, "已复制全部结果", Toast.LENGTH_SHORT).show();
            }
        }));
        row.addView(smallButton("关闭", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dlg.dismiss();
            }
        }));
        card.addView(row);

        dialog.setContentView(card);
        Window w = dialog.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(0x00000000));
            w.setLayout(getResources().getDisplayMetrics().widthPixels - dp(40),
                    WindowManager.LayoutParams.WRAP_CONTENT);
        }
        dialog.show();
    }

    private void pickImage() {
        Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
        pick.setType("image/*");
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        try {
            startActivityForResult(Intent.createChooser(pick, "选择图片"), REQ_PICK);
        } catch (Throwable t) {
            Toast.makeText(this, "没有可用的相册应用", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;
        if (requestCode == REQ_SCAN) {
            String text = data.getStringExtra("text");
            String fmt = data.getStringExtra("format");
            if (text != null) {
                HistoryStore.add(this, text, fmt == null ? "" : fmt);
                showResult(text, fmt == null ? "" : fmt);
            }
        } else if (requestCode == REQ_BATCH) {
            handleBatch(data);
        } else if (requestCode == REQ_PICK) {
            Uri uri = data.getData();
            if (uri == null) return;
            try {
                Bitmap bmp = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                String text = QrUtils.decode(bmp);
                if (text == null) {
                    Toast.makeText(this, "这张图片里没识别到二维码", Toast.LENGTH_LONG).show();
                } else {
                    HistoryStore.add(this, text, "");
                    showResult(text, "");
                }
            } catch (Throwable t) {
                Toast.makeText(this, "读取图片失败：" + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void showResult(final String text, final String format) {
        android.app.Dialog dialog = new android.app.Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(16), dp(18), dp(14));
        card.setBackground(rounded(0xFFFFFFFF, 20));

        TextView t = new TextView(this);
        t.setText(format.length() > 0 ? "识别结果 · " + format : "识别结果");
        t.setTextSize(15);
        t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        t.setTextColor(0xFF16233A);
        card.addView(t);

        TextView content = new TextView(this);
        content.setText(text);
        content.setTextSize(14);
        content.setTextIsSelectable(true);
        content.setTextColor(0xFF1B2230);
        content.setPadding(dp(12), dp(10), dp(12), dp(10));
        GradientDrawable bg = rounded(0xFFF6F7FB, 12);
        content.setBackground(bg);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        clp.topMargin = dp(8);
        content.setLayoutParams(clp);
        card.addView(content);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rlp.topMargin = dp(10);
        row.setLayoutParams(rlp);

        final android.app.Dialog dlg = dialog;
        row.addView(smallButton("复制", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                copy(text);
                Toast.makeText(MainActivity.this, "已复制", Toast.LENGTH_SHORT).show();
            }
        }));
        if (text.startsWith("http://") || text.startsWith("https://")) {
            row.addView(smallButton("打开链接", new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(text)));
                    } catch (Throwable t) {
                        Toast.makeText(MainActivity.this, "无法打开链接", Toast.LENGTH_SHORT).show();
                    }
                }
            }));
        }
        row.addView(smallButton("关闭", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dlg.dismiss();
            }
        }));
        card.addView(row);

        dialog.setContentView(card);
        Window w = dialog.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(0x00000000));
            w.setLayout(getResources().getDisplayMetrics().widthPixels - dp(48),
                    WindowManager.LayoutParams.WRAP_CONTENT);
        }
        dialog.show();
    }

    private void copy(String text) {
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("二维码内容", text));
    }

    // ================= 设置 =================

    private String versionName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Throwable t) {
            return "?";
        }
    }

    private void showSettings() {
        final android.app.Dialog dialog = new android.app.Dialog(this);
        settingsDialog = dialog;
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(rounded(0xFFFFFFFF, 24));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(18), dp(14), dp(18), dp(4));

        TextView t = new TextView(this);
        t.setText("设置");
        t.setTextSize(17);
        t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        t.setTextColor(0xFF16233A);
        header.addView(t);

        TextView st = new TextView(this);
        st.setText("二维码工具箱 v" + versionName());
        st.setTextSize(10);
        st.setTextColor(0xFF98A0AE);
        st.setPadding(0, dp(4), 0, 0);
        header.addView(st);
        card.addView(header);

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(14), dp(2), dp(14), dp(2));

        TextView gl = new TextView(this);
        gl.setText("关于");
        gl.setTextSize(11);
        gl.setTextColor(0xFF98A0AE);
        gl.setPadding(dp(6), dp(10), dp(6), dp(6));
        body.addView(gl);

        LinearLayout group = new LinearLayout(this);
        group.setOrientation(LinearLayout.VERTICAL);
        group.setBackground(rounded(0xFFF6F7FB, 14));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(10), dp(12), dp(10));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView label = new TextView(this);
        label.setText("检查应用更新");
        label.setTextSize(13);
        label.setTextColor(0xFF1B2230);
        texts.addView(label);

        TextView subLabel = new TextView(this);
        subLabel.setText("当前 v" + versionName());
        subLabel.setTextSize(10);
        subLabel.setTextColor(0xFF98A0AE);
        subLabel.setPadding(0, dp(2), 0, 0);
        texts.addView(subLabel);
        row.addView(texts);

        TextView act = new TextView(this);
        act.setText("检查");
        act.setTextSize(13);
        act.setTextColor(0xFF2F6BFF);
        row.addView(act);

        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                otaManager.checkUpdate(true);
            }
        });
        group.addView(row);
        body.addView(group);

        card.addView(body);

        TextView done = new TextView(this);
        done.setText("完成");
        done.setTextSize(14);
        done.setTextColor(0xFF2F6BFF);
        done.setGravity(Gravity.CENTER);
        done.setBackground(rounded(0xFFF1F5FF, 14));
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(44));
        dlp.setMargins(dp(14), dp(6), dp(14), dp(14));
        done.setLayoutParams(dlp);
        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        card.addView(done);

        dialog.setContentView(card);
        Window w = dialog.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(0x00000000));
            w.setLayout(getResources().getDisplayMetrics().widthPixels - dp(44),
                    WindowManager.LayoutParams.WRAP_CONTENT);
        }
        dialog.show();
    }

    @Override
    protected void onDestroy() {
        if (otaManager != null) otaManager.release();
        super.onDestroy();
    }
}
