package com.example.qrtool;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** 扫描历史：搜索、复制、单条删除、清空 */
public class HistoryActivity extends Activity {

    private LinearLayout listBox;
    private TextView emptyView;
    private String keyword = "";
    private String catFilter = "all";   // all / qr / barcode
    private final java.util.ArrayList<JSONObject> filtered = new java.util.ArrayList<>();
    private TextView chipAll, chipQr, chipBar;
    private final SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        immersive();
        build();
    }

    private void immersive() {
        Window w = getWindow();
        w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        w.setStatusBarColor(0x00000000);
        if (Build.VERSION.SDK_INT >= 26) w.setNavigationBarColor(0x00000000);
        int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        if (Build.VERSION.SDK_INT >= 26) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        w.getDecorView().setSystemUiVisibility(flags);
    }

    private int statusBarHeight() {
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : dp(24);
    }

    private void build() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFFE6F0FF, 0xFFF2F7FF, 0xFFEDF4FF, 0xFFF9FBFF}));
        scroll.setFillViewport(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), statusBarHeight() + dp(14), dp(18), dp(24));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);

        TextView back = new TextView(this);
        back.setText("‹ 返回");
        back.setTextSize(14);
        back.setTextColor(0xFF2F6BFF);
        back.setPadding(0, dp(6), dp(10), dp(6));
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        bar.addView(back);

        TextView title = new TextView(this);
        title.setText("扫描历史");
        title.setTextSize(20);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        title.setTextColor(0xFF16233A);
        title.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        bar.addView(title);

        TextView export = new TextView(this);
        export.setText("导出");
        export.setTextSize(13);
        export.setTextColor(0xFF2F6BFF);
        export.setPadding(dp(10), dp(6), dp(6), dp(6));
        export.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exportResults();
            }
        });
        bar.addView(export);

        TextView clear = new TextView(this);
        clear.setText("清空");
        clear.setTextSize(13);
        clear.setTextColor(0xFF2F6BFF);
        clear.setPadding(dp(10), dp(6), 0, dp(6));
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(HistoryActivity.this)
                        .setTitle("清空扫描历史")
                        .setMessage("删除全部记录？不可恢复。")
                        .setPositiveButton("清空", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int w) {
                                HistoryStore.clear(HistoryActivity.this);
                                refresh();
                            }
                        })
                        .setNegativeButton("取消", null)
                        .show();
            }
        });
        bar.addView(clear);
        root.addView(bar);

        EditText search = new EditText(this);
        search.setHint("搜索内容或码类型");
        search.setTextSize(14);
        search.setSingleLine(true);
        search.setInputType(InputType.TYPE_CLASS_TEXT);
        search.setTextColor(0xFF1B2230);
        search.setPadding(dp(12), dp(8), dp(12), dp(8));
        GradientDrawable sbg = rounded(0xFFFFFFFF, 12);
        sbg.setStroke(dp(1), 0x33A9C4EA);
        search.setBackground(sbg);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        slp.topMargin = dp(10);
        search.setLayoutParams(slp);
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                keyword = s.toString().trim().toLowerCase(Locale.getDefault());
                refresh();
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
        root.addView(search);

        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams chipLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        chipLp.topMargin = dp(10);
        chips.setLayoutParams(chipLp);

        chipAll = chip("全部", "all");
        chipQr = chip("二维码", "qr");
        chipBar = chip("条形码", "barcode");
        chips.addView(chipAll);
        chips.addView(chipQr);
        chips.addView(chipBar);
        root.addView(chips);

        listBox = new LinearLayout(this);
        listBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(listBox);

        emptyView = new TextView(this);
        emptyView.setText("还没有扫描记录");
        emptyView.setTextSize(13);
        emptyView.setTextColor(0xFF98A0AE);
        emptyView.setGravity(Gravity.CENTER);
        emptyView.setPadding(0, dp(40), 0, 0);
        root.addView(emptyView);

        scroll.addView(root);
        setContentView(scroll);
        refresh();
    }

    private TextView chip(String text, final String key) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(13);
        tv.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(36), 1f);
        lp.rightMargin = dp(4);
        lp.leftMargin = dp(4);
        tv.setLayoutParams(lp);
        tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                catFilter = key;
                refresh();
            }
        });
        styleChip(tv, key.equals(catFilter));
        return tv;
    }

    private void styleChip(TextView tv, boolean selected) {
        if (selected) {
            GradientDrawable bg = rounded(0xFF2F6BFF, 12);
            tv.setBackground(bg);
            tv.setTextColor(0xFFFFFFFF);
        } else {
            GradientDrawable bg = rounded(0xFFFFFFFF, 12);
            bg.setStroke(dp(1), 0x332F6BFF);
            tv.setBackground(bg);
            tv.setTextColor(0xFF2F6BFF);
        }
    }

    /** 导出入口：先让用户选文件名 */
    private void exportResults() {
        if (filtered.isEmpty()) {
            Toast.makeText(this, "没有可导出的结果", Toast.LENGTH_SHORT).show();
            return;
        }
        final String defaultName = "条码扫描结果-"
                + new SimpleDateFormat("yyyyMMdd-HHmm", Locale.getDefault()).format(new Date());
        new AlertDialog.Builder(this)
                .setTitle("导出 " + filtered.size() + " 条结果")
                .setPositiveButton("用默认名称", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        doExport(defaultName);
                    }
                })
                .setNegativeButton("自定义名称", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        askCustomName(defaultName);
                    }
                })
                .setNeutralButton("取消", null)
                .show();
    }

    /** 自定义文件名 */
    private void askCustomName(String defaultName) {
        final EditText edit = new EditText(this);
        edit.setText(defaultName);
        edit.setSingleLine(true);
        edit.setSelection(defaultName.length());
        edit.setPadding(dp(16), dp(10), dp(16), dp(10));
        new AlertDialog.Builder(this)
                .setTitle("文件名称")
                .setMessage("保存在 Download/条码扫描/，自动加 .txt")
                .setView(edit)
                .setPositiveButton("导出", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        String name = edit.getText().toString().trim();
                        if (name.length() == 0) name = defaultName;
                        if (name.endsWith(".txt")) name = name.substring(0, name.length() - 4);
                        // 去掉文件名里非法的字符
                        name = name.replaceAll("[\\\\/:*?\"<>|]", "_");
                        doExport(name);
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    /** 真正写入文件（只写扫描结果，一行一条） */
    private void doExport(String baseName) {
        StringBuilder sb = new StringBuilder();
        for (JSONObject o : filtered) {
            sb.append(o.optString("x")).append("\n");
        }
        String content = sb.toString();
        String name = baseName + ".txt";
        String savedPath = null;
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                android.content.ContentValues v = new android.content.ContentValues();
                v.put(android.provider.MediaStore.Downloads.DISPLAY_NAME, name);
                v.put(android.provider.MediaStore.Downloads.MIME_TYPE, "text/plain");
                v.put(android.provider.MediaStore.Downloads.RELATIVE_PATH, "Download/条码扫描");
                android.net.Uri uri = getContentResolver().insert(
                        android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri != null) {
                    java.io.OutputStream os = getContentResolver().openOutputStream(uri);
                    os.write(content.getBytes("UTF-8"));
                    os.close();
                    savedPath = "下载/条码扫描/" + name;
                }
            } else {
                java.io.File dir = Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_DOWNLOADS);
                if (!dir.exists()) dir.mkdirs();
                java.io.File f = new java.io.File(dir, name);
                java.io.FileOutputStream fos = new java.io.FileOutputStream(f);
                fos.write(content.getBytes("UTF-8"));
                fos.close();
                savedPath = f.getAbsolutePath();
            }
        } catch (Throwable t) {
            savedPath = null;
        }

        if (savedPath != null) {
            Toast.makeText(this, "已导出 " + filtered.size() + " 条到 " + savedPath,
                    Toast.LENGTH_LONG).show();
        } else {
            // 兜底：直接分享文本
            android.content.Intent send = new android.content.Intent(android.content.Intent.ACTION_SEND);
            send.setType("text/plain");
            send.putExtra(android.content.Intent.EXTRA_TEXT, content);
            startActivity(android.content.Intent.createChooser(send, "导出扫描结果"));
        }
    }

    private void refresh() {
        listBox.removeAllViews();
        filtered.clear();
        JSONArray arr = HistoryStore.load(this);
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            String text = o.optString("x");
            String format = o.optString("f");
            String cat = o.optString("c");
            if (cat.length() == 0) cat = HistoryStore.category(format);
            if (!"all".equals(catFilter)) {
                if ("qr".equals(catFilter) && !"qr".equals(cat)) continue;
                if ("barcode".equals(catFilter) && !"barcode".equals(cat)) continue;
            }
            String hay = (text + " " + format).toLowerCase(Locale.getDefault());
            if (keyword.length() > 0 && !hay.contains(keyword)) continue;
            filtered.add(o);
        }
        for (JSONObject o : filtered) {
            listBox.addView(row(o.optString("x"), o.optString("f"),
                    o.optLong("t"), o.optString("i")));
        }
        emptyView.setText(keyword.length() > 0
                ? "没有匹配的记录"
                : ("all".equals(catFilter) ? "还没有扫描记录"
                   : ("qr".equals(catFilter) ? "还没有二维码记录" : "还没有条形码记录")));
        emptyView.setVisibility(filtered.isEmpty() ? View.VISIBLE : View.GONE);

        if (chipAll != null) {
            styleChip(chipAll, "all".equals(catFilter));
            styleChip(chipQr, "qr".equals(catFilter));
            styleChip(chipBar, "barcode".equals(catFilter));
        }
    }

    /** 看大图 */
    private void showImage(String path) {
        final android.app.Dialog dialog = new android.app.Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        android.widget.ImageView iv = new android.widget.ImageView(this);
        iv.setAdjustViewBounds(true);
        iv.setScaleType(android.widget.ImageView.ScaleType.FIT_CENTER);
        try {
            android.graphics.BitmapFactory.Options opt = new android.graphics.BitmapFactory.Options();
            opt.inSampleSize = 2;
            iv.setImageBitmap(android.graphics.BitmapFactory.decodeFile(path, opt));
        } catch (Throwable ignored) {
        }
        iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.setContentView(iv);
        Window w = dialog.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0xFF000000));
            w.setLayout(getResources().getDisplayMetrics().widthPixels - dp(30),
                    WindowManager.LayoutParams.WRAP_CONTENT);
        }
        dialog.show();
    }

    private View row(final String text, final String format, final long time, final String imgPath) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(dp(10), dp(10), dp(14), dp(10));
        GradientDrawable bg = rounded(0xF2FFFFFF, 16);
        bg.setStroke(dp(1), 0x55FFFFFF);
        box.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(8);
        box.setLayoutParams(lp);

        // 扫描时的画面缩略图（点一下看大图）
        if (imgPath != null && imgPath.length() > 0) {
            android.widget.ImageView thumb = new android.widget.ImageView(this);
            thumb.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
            int ts = dp(54);
            LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(ts, ts);
            tlp.rightMargin = dp(10);
            thumb.setLayoutParams(tlp);
            GradientDrawable tbg = rounded(0xFFEDF2FB, 10);
            thumb.setBackground(tbg);
            try {
                android.graphics.BitmapFactory.Options opt = new android.graphics.BitmapFactory.Options();
                opt.inSampleSize = 4;
                thumb.setImageBitmap(android.graphics.BitmapFactory.decodeFile(imgPath, opt));
            } catch (Throwable ignored) {
            }
            thumb.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showImage(imgPath);
                }
            });
            box.addView(thumb);
        }

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        box.addView(col);

        TextView content = new TextView(this);
        content.setText(text);
        content.setTextSize(14);
        content.setMaxLines(3);
        content.setTextColor(0xFF1B2230);
        col.addView(content);

        TextView meta = new TextView(this);
        meta.setText(fmt.format(new Date(time)) + (format.length() > 0 ? "  ·  " + format : ""));
        meta.setTextSize(11);
        meta.setTextColor(0xFF98A0AE);
        meta.setPadding(0, dp(4), 0, 0);
        col.addView(meta);

        box.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("扫描内容", text));
                Toast.makeText(HistoryActivity.this, "已复制", Toast.LENGTH_SHORT).show();
            }
        });
        box.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                new AlertDialog.Builder(HistoryActivity.this)
                        .setTitle("删除这条记录？")
                        .setPositiveButton("删除", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int w) {
                                HistoryStore.remove(HistoryActivity.this, time, text);
                                refresh();
                            }
                        })
                        .setNegativeButton("取消", null)
                        .show();
                return true;
            }
        });
        return box;
    }
}
