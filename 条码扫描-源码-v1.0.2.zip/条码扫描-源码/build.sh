#!/bin/bash
set -e

SDK=/home/user/toolchain/android-sdk
BT=$SDK/build-tools/34.0.0
PLATFORM=$SDK/platforms/android-34/android.jar
JAVA_HOME=/home/user/toolchain/jdk-17.0.10+7
export PATH=$JAVA_HOME/bin:$PATH

cd "$(dirname "$0")"
OUT=build
rm -rf "$OUT"
mkdir -p "$OUT/compiled" "$OUT/gen" "$OUT/classes" "$OUT/dex"

LIBS=$(ls libs/*.jar 2>/dev/null | tr '\n' ':' || true)

"$BT/aapt2" compile --dir res -o "$OUT/compiled/res.zip"

"$BT/aapt2" link \
  -o "$OUT/base.apk" \
  -I "$PLATFORM" \
  --manifest AndroidManifest.xml \
  --min-sdk-version 24 \
  --target-sdk-version 34 \
  --java "$OUT/gen" \
  "$OUT/compiled/res.zip"

find src "$OUT/gen" -name "*.java" > "$OUT/sources.txt"
javac -source 8 -target 8 -encoding UTF-8 \
  -classpath "$PLATFORM:$LIBS" \
  -d "$OUT/classes" \
  @"$OUT/sources.txt" 2>&1 | grep -v "bootstrap class path" || true

"$BT/d8" --lib "$PLATFORM" --min-api 24 --output "$OUT/dex" \
  $(find "$OUT/classes" -name "*.class") libs/*.jar

cp "$OUT/base.apk" "$OUT/unsigned.apk"
cd "$OUT"
cp dex/classes.dex .
zip -q -u unsigned.apk classes.dex
cd ..

"$BT/zipalign" -f -p 4 "$OUT/unsigned.apk" "$OUT/aligned.apk"

KEYSTORE="${RELEASE_KEYSTORE:-$PWD/../secrets/qrtool-release.keystore}"
KS_PASS="${RELEASE_STOREPASS:-QRKit-2027-release}"
KS_ALIAS="${RELEASE_ALIAS:-qrtoolrelease}"
if [ ! -f "$KEYSTORE" ]; then
  echo "缺少 release 密钥库：$KEYSTORE"; exit 1
fi

"$BT/apksigner" sign \
  --ks "$KEYSTORE" --ks-pass "pass:$KS_PASS" \
  --key-pass "pass:$KS_PASS" --ks-key-alias "$KS_ALIAS" \
  --out "$OUT/app-debug.apk" "$OUT/aligned.apk"

"$BT/apksigner" verify --print-certs "$OUT/app-debug.apk" | head -5
ls -lh "$OUT/app-debug.apk"
